class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception

  def set_current_user
    if session[:current_user_id]
      @current_user = User.find(session[:current_user_id])
    else
      redirect_to login_users_path 
    end
  end

  def set_cart
    if session[:cart_id]
      @cart = Cart.find(session[:cart_id])
    else
      @cart = Cart.create(user: @current_user)
      session[:cart_id] = @cart.id
    end
  end
end
