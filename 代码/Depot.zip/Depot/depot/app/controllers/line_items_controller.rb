class LineItemsController < ApplicationController
  before_action :set_current_user, :set_cart, only: [:create]

  # POST /line_items
  # POST /line_items.json
  def create
    @product = Product.find(params[:product_id])
    @cart.line_items.create(product: @product, quantity: 1, price: @product.price)

    respond_to do |format|
      format.html { redirect_to @cart, notice: 'Line item was successfully created.' }
    end
  end
end
