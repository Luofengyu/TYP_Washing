module CartsHelper
  def total_quantity(cart)
    cart.line_items.map(&:quantity).sum
  end

  def total_price(cart)
    cart.line_items.map do |line_item| 
      line_item.price * line_item.quantity
    end.sum
  end
end
