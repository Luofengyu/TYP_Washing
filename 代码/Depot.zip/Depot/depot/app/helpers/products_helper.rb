module ProductsHelper
  def show_price(price)
    number_to_currency(price, unit: '$')+'元'
  end
end