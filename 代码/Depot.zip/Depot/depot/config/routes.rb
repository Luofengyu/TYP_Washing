Rails.application.routes.draw do
  resources :orders
  resources :line_items
  resources :carts
  resources :users do 
    collection do 
      get :login
      post :login
    end
  end
  get 'store/index'
  get 'store/:id', to: 'store#show', as: 'store_product'

  resources :products
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
